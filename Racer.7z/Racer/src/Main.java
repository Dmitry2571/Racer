import  ru.racer.Application;

/**
 * Created by Дмитрий on 19.01.2019.
 */

public class Main{
    private static final int  N = 4;
    public static void main(String[] args) {
        Application app = new Application(N);
        app.start();
    }
}
